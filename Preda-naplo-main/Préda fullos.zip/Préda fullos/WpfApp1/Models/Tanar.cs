﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WpfApp1.Models
{
    internal class Tanar : Felhasznalo
    {
        public List<string> Tantargyak { get; set; } = new List<string>();
        public List<string> TanitottOsztalyok { get; set; } = new List<string>();

        public Tanar(string felhasznalonev, string jelszo, string nev, string iskolaNev, string osztaly = "")
            : base(felhasznalonev, jelszo, nev, iskolaNev, "Tanár", osztaly)
        {
            Tantargyak = new List<string>();
            TanitottOsztalyok = new List<string>();
        }

        public Tanar(string felhasznalonev, string jelszo, string nev, string iskolaNev, string osztaly,
                     List<string> tantargyak, List<string> tanitottOsztalyok = null)
            : base(felhasznalonev, jelszo, nev, iskolaNev, "Tanár", osztaly)
        {
            Tantargyak = tantargyak ?? new List<string>();
            TanitottOsztalyok = tanitottOsztalyok ?? new List<string>();
        }

        public override string ToFileFormat()
        {
            string tantargyakString = string.Join(",", Tantargyak);
            string osztalyokString = string.Join(",", TanitottOsztalyok);
            return $"{Felhasznalonev};{GetJelszo()};{Nev};{IskolaNev};{Szerepkor};{osztalyokString};{tantargyakString}";
        }

        public bool Tanitja(string tantargy)
        {
            return Tantargyak.Contains(tantargy);
        }

        public bool TanitjaOsztalyt(string osztaly)
        {
            return TanitottOsztalyok.Contains(osztaly);
        }

        public override void FoMenu(JegyManager jegyManager, KozlemenyManager kozlemenyManager, HianyzasManager hianyzasManager)
        {
            // This is the console version; you may keep it or ignore.
            while (true)
            {
                Console.Clear();
                Console.WriteLine($"TANÁRI MENÜ - {Nev}");
                if (!string.IsNullOrEmpty(Osztaly))
                {
                    Console.WriteLine($"Osztály: {Osztaly}");
                }
                Console.WriteLine("[1] Jegyek megtekintése");
                Console.WriteLine("[2] Új jegy rögzítése");
                Console.WriteLine("[3] Jegy írás osztálynak");
                Console.WriteLine("[4] Súlyozott jegy rögzítése");
                Console.WriteLine("[5] Hiányzás rögzítése");
                Console.WriteLine("[6] Hiányzások listázása");
                Console.WriteLine("[7] Hiányzás igazolása");
                Console.WriteLine("[8] Fellebbezések kezelése");
                Console.WriteLine("[9] Diák lezárása");
                Console.WriteLine("[0] Kijelentkezés");
                Console.Write("\nVálasztás: ");
                string valasztas = Console.ReadLine();

                if (valasztas == "1")
                {
                    jegyManager.JegyekListazasa(this);
                    Console.WriteLine("\nNyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "2")
                {
                    jegyManager.UjJegy(this);
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "3")
                {
                    jegyManager.JegyIrasOsztalynak(this);
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "4")
                {
                    jegyManager.UjJegySullyal(this);
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "5")
                {
                    hianyzasManager.HianyzasRogzitese(this);
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "6")
                {
                    hianyzasManager.HianyzasokListazasa(this);
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "7")
                {
                    hianyzasManager.HianyzasIgazolasa(this);
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "8")
                {
                    jegyManager.FellebbezesekKezelese(this);
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "9")
                {
                    Console.WriteLine("\n=== DIÁK LEZÁRÁSA ===");
                    Console.WriteLine("Ez a funkció lehetővé teszi az év végi jegyek lezárását.");
                    Console.WriteLine("A lezárás után a jegyek már nem módosíthatók.");
                    Console.Write("\nBiztosan le szeretnéd zárni az osztályzatokat? (i/n): ");
                    string valasz = Console.ReadLine().ToLower();
                    if (valasz == "i")
                        Console.WriteLine("✅ Osztályzatok sikeresen lezárva!");
                    else
                        Console.WriteLine("❌ Lezárás megszakítva.");
                    Console.WriteLine("Nyomj ENTER-t a folytatáshoz...");
                    Console.ReadLine();
                }
                else if (valasztas == "0")
                {
                    Console.WriteLine("Kijelentkezés...");
                    break;
                }
                else
                {
                    Console.WriteLine("Érvénytelen választás!");
                    Console.ReadLine();
                }
            }
        }
    }
}